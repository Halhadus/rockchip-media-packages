#define UTS_RELEASE "7.0-arm64"
