#define UTS_VERSION "#1 SMP PREEMPT Debian 7.0.1-1~exp1 (2026-04-23)"
