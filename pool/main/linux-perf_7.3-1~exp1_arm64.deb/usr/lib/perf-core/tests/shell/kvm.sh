#!/bin/bash
# perf kvm tests
# SPDX-License-Identifier: GPL-2.0

set -e

err=0
perfdata=$(mktemp /tmp/__perf_kvm_test.perf.data.XXXXX)
qemu_pid_file=$(mktemp /tmp/__perf_kvm_test.qemu.pid.XXXXX)
log_file=$(mktemp /tmp/__perf_kvm_test.live_log.XXXXX)

cleanup() {
	rm -f "${perfdata}" "${log_file}"
	if [ -f "${qemu_pid_file}" ]; then
		if [ -s "${qemu_pid_file}" ]; then
			qemu_pid=$(cat "${qemu_pid_file}")
			if [ -n "${qemu_pid}" ]; then
				kill "${qemu_pid}" 2>/dev/null || true
			fi
		fi
		rm -f "${qemu_pid_file}"
	fi
	trap - EXIT TERM INT
}

trap_cleanup() {
	echo "Unexpected signal in ${FUNCNAME[1]}"
	cleanup
	exit 1
}
trap trap_cleanup EXIT TERM INT

skip() {
	echo "Skip: $1"
	cleanup
	exit 2
}

test_kvm_stat() {
	echo "Testing perf kvm stat"

	local duration
	local success=false
	for duration in 1 2 4 8; do
		echo "Recording kvm events for pid ${qemu_pid} (duration ${duration}s)..."
		rm -f "${perfdata}" "${perfdata}".old
		if ! perf kvm stat record -p "${qemu_pid}" -o "${perfdata}" \
			sleep ${duration} >/dev/null 2>&1; then
			echo "perf kvm stat record failed, retrying..."
			continue
		fi

		if [ -e "${perfdata}" ] && \
			perf kvm -i "${perfdata}" stat report 2>&1 | grep -q "VM-EXIT"; then
			success=true
			break
		fi
		echo "No VM-EXIT events found, retrying..."
	done

	if [ "$success" = false ]; then
		echo "Failed to find VM-EXIT in report"
		perf kvm -i "${perfdata}" stat report 2>&1 || true
		err=1
		return
	fi

	echo "perf kvm stat test [Success]"
}

test_kvm_record_report() {
	echo "Testing perf kvm record/report"

	local duration
	local success=false
	for duration in 1 2 4 8; do
		echo "Recording kvm profile for pid ${qemu_pid} (duration ${duration}s)..."
		rm -f "${perfdata}" "${perfdata}".old

		perf kvm --host record -p "${qemu_pid}" -o "${perfdata}" \
			-e cpu-clock sleep ${duration}

		if [ -e "${perfdata}" ] && \
			perf kvm -i "${perfdata}" report --stdio 2>&1 | grep -q "Event count"; then
			success=true
			break
		fi
		echo "No samples or report failed, retrying..."
	done

	if [ "$success" = false ]; then
		echo "Failed to report kvm profile"
		perf kvm -i "${perfdata}" report --stdio 2>&1 || true
		err=1
		return
	fi

	echo "perf kvm record/report test [Success]"
}

test_kvm_buildid_list() {
	echo "Testing perf kvm buildid-list"

	# We reuse the perf.data from the previous record test
	if ! perf kvm --host -i "${perfdata}" buildid-list 2>&1 | grep -q "."; then
		echo "Failed to list buildids"
		perf kvm --host -i "${perfdata}" buildid-list 2>&1
		err=1
		return
	fi

	echo "perf kvm buildid-list test [Success]"
}

test_kvm_stat_live() {
	echo "Testing perf kvm stat live"

        # Run perf kvm live for 5 seconds, monitoring that PID
	# Use sleep to keep stdin open but silent, preventing EOF loop or interactive spam
	if ! sleep 10 | timeout 5s perf kvm stat live -p "${qemu_pid}" > "${log_file}" 2>&1; then
		retval=$?
		if [ $retval -ne 124 ] && [ $retval -ne 0 ]; then
			echo "perf kvm stat live [Failed: perf kvm stat live failed to start or run (ret=$retval)]"
			head -n 50 "${log_file}"
			err=1
			return
		fi
	fi

	# Check for some sample data (percentage)
	if ! grep -E -q "[0-9]+\.[0-9]+%" "${log_file}"; then
		echo "perf kvm stat live [Failed: no sample percentage found]"
		head -n 50 "${log_file}"
		err=1
		return
	fi

	echo "perf kvm stat live test [Success]"
}

test_kvm_default_event() {
	echo "Testing perf kvm record default event with command line"

	# Check if kvm record with default events handle command line arguments
	perf kvm record -p "${qemu_pid}" -o /dev/null sleep 1

	echo "perf kvm record default event [Success]"
}

setup_qemu() {
	# Find qemu
	if [ "$(uname -m)" = "x86_64" ]; then
		qemu="qemu-system-x86_64"
	elif [ "$(uname -m)" = "aarch64" ]; then
		qemu="qemu-system-aarch64"
	elif [ "$(uname -m)" = "s390x" ]; then
		qemu="qemu-system-s390x"
	elif [ "$(uname -m)" = "ppc64le" ]; then
		qemu="qemu-system-ppc64"
	else
		qemu="qemu-system-$(uname -m)"
	fi

	if ! which -s "$qemu"; then
		skip "$qemu not found"
	fi

	if [ ! -r /dev/kvm ] || [ ! -w /dev/kvm ]; then
		skip "/dev/kvm not accessible"
	fi

	if ! perf kvm stat record -o /dev/null -a sleep 0.01 >/dev/null 2>&1; then
		skip "No permission to record kvm events"
	fi

	echo "Starting $qemu..."
	# Start qemu in background, detached, with pidfile
	# We use -display none -daemonize and a monitor to keep it alive/controllable if needed
	# We don't need a real kernel, just KVM active.
	if ! $qemu -enable-kvm -display none -daemonize -pidfile "${qemu_pid_file}" -monitor none; then
		echo "Failed to start qemu"
		err=1
		return
	fi

	# Wait a bit for qemu to start
	sleep 1
	qemu_pid=$(cat "${qemu_pid_file}")

	if ! kill -0 "${qemu_pid}" 2>/dev/null; then
		echo "Qemu process failed to stay alive"
		err=1
		return
	fi
}

setup_qemu
if [ $err -eq 0 ]; then
	test_kvm_stat
	test_kvm_record_report
	test_kvm_buildid_list
	test_kvm_stat_live
	test_kvm_default_event
fi

cleanup
exit $err
