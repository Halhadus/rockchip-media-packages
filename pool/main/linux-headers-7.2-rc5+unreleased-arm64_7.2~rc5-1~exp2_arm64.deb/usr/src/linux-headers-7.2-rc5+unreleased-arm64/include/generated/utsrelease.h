#define UTS_RELEASE "7.2-rc5+unreleased-arm64"
