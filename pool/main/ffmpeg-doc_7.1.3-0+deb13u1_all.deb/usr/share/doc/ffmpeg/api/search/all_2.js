var searchData=
[
  ['_5fwin32_5fwinnt_0',['_win32_winnt',['../d3d11va_8h.html#ac50762666aa00bd3a4308158510f1748',1,'_WIN32_WINNT:&#160;d3d11va.h'],['../dxva2_8h.html#ac50762666aa00bd3a4308158510f1748',1,'_WIN32_WINNT:&#160;dxva2.h']]],
  ['_5fxopen_5fsource_1',['_XOPEN_SOURCE',['../decode__filter__video_8c.html#a78c99ffd76a7bb3c8c74db76207e9ab4',1,'decode_filter_video.c']]]
];
