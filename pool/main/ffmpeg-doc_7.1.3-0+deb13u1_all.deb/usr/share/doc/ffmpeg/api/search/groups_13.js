var searchData=
[
  ['un_20initialization_20and_20inspection_0',['AVOption (un)initialization and inspection.',['../group__opt__mng.html',1,'']]],
  ['utility_1',['Colorspace Utility',['../group__lavu__math__csp.html',1,'']]],
  ['utility_20functions_2',['utility functions',['../group__lavf__misc.html',1,'Utility functions'],['../group__lavc__misc.html',1,'Utility functions']]]
];
