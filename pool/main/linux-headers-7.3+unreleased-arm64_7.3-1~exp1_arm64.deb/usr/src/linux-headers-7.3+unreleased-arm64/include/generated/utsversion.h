#define UTS_VERSION "#1 SMP PREEMPT Debian 7.3-1~exp1 (2026-10-19)"
