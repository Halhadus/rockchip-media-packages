#define UTS_RELEASE "7.2.3-arm64"
