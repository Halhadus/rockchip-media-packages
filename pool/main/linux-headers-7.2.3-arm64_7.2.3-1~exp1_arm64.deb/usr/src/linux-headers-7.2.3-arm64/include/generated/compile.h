#define UTS_MACHINE		"aarch64"
#define LINUX_COMPILE_BY	"debian-kernel"
#define LINUX_COMPILE_HOST	"lists.debian.org"
#define LINUX_COMPILER		"aarch64-linux-gnu-gcc-16 (Debian 16.2.0-2) 16.2.0, GNU ld (GNU Binutils for Debian) 2.47"
