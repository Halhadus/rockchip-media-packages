#define UTS_RELEASE "7.2-rc3-arm64"
