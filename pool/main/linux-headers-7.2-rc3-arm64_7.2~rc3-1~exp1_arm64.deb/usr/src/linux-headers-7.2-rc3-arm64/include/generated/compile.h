#define UTS_MACHINE		"aarch64"
#define LINUX_COMPILE_BY	"debian-kernel"
#define LINUX_COMPILE_HOST	"lists.debian.org"
#define LINUX_COMPILER		"aarch64-linux-gnu-gcc-15 (Debian 15.3.0-1) 15.3.0, GNU ld (GNU Binutils for Debian) 2.46.90.20260712"
