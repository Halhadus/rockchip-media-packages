var searchData=
[
  ['media_20file_0',['Opening a media file',['../group__lavf__decoding.html#lavf_decoding_open',1,'']]],
  ['muxers_1',['Passing options to (de)muxers',['../group__libavf.html#lavf_options',1,'']]]
];
