var searchData=
[
  ['named_20constants_0',['Named constants',['../group__avoptions.html#avoptions_implement_named_constants',1,'']]],
  ['nesting_1',['Nesting',['../group__avoptions.html#avoptions_implement_nesting',1,'']]]
];
