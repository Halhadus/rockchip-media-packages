var searchData=
[
  ['code_0',['Code',['../group__lavu__hash__generic.html#Sample',1,'']]],
  ['compatibility_1',['Versioning and compatibility',['../index.html#ffmpeg_versioning',1,'']]],
  ['constants_2',['Named constants',['../group__avoptions.html#avoptions_implement_named_constants',1,'']]]
];
