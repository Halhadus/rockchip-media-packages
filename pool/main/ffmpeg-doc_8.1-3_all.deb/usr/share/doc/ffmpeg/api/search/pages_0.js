var searchData=
[
  ['a_20directory_0',['Opening a directory',['../group__lavf__io.html#lavf_io_dirlist_open',1,'']]],
  ['a_20media_20file_1',['Opening a media file',['../group__lavf__decoding.html#lavf_decoding_open',1,'']]],
  ['an_20opened_20file_2',['Reading from an opened file',['../group__lavf__decoding.html#lavf_decoding_read',1,'']]],
  ['and_20compatibility_3',['Versioning and compatibility',['../index.html#ffmpeg_versioning',1,'']]],
  ['and_20writing_20avoptions_4',['Reading and writing AVOptions',['../group__avoptions.html#avoptions_use_get_set',1,'']]],
  ['avoptions_5',['AVOptions',['../group__avoptions.html#avoptions_use_examine',1,'Examining AVOptions'],['../group__avoptions.html#avoptions_implement',1,'Implementing AVOptions'],['../group__avoptions.html#avoptions_use_get_set',1,'Reading and writing AVOptions'],['../group__avoptions.html#avoptions_scope',1,'Scope of AVOptions'],['../group__avoptions.html#avoptions_use',1,'Using AVOptions']]]
];
