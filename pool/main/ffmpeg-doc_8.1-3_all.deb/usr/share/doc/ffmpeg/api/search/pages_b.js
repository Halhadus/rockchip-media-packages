var searchData=
[
  ['reading_20and_20writing_20avoptions_0',['Reading and writing AVOptions',['../group__avoptions.html#avoptions_use_get_set',1,'']]],
  ['reading_20entries_1',['Reading entries',['../group__lavf__io.html#lavf_io_dirlist_read',1,'']]],
  ['reading_20from_20an_20opened_20file_2',['Reading from an opened file',['../group__lavf__decoding.html#lavf_decoding_read',1,'']]]
];
