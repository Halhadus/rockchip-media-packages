var searchData=
[
  ['entries_0',['Reading entries',['../group__lavf__io.html#lavf_io_dirlist_read',1,'']]],
  ['examining_20avoptions_1',['Examining AVOptions',['../group__avoptions.html#avoptions_use_examine',1,'']]]
];
