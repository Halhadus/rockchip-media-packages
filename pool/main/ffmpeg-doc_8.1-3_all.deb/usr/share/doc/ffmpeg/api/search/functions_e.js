var searchData=
[
  ['type_5fstring_0',['type_string',['../avio__list__dir_8c.html#a9db32df956b732dc626695826781cbc6',1,'avio_list_dir.c']]]
];
