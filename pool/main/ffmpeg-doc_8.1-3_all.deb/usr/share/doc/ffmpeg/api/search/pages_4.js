var searchData=
[
  ['ffmpeg_0',['FFmpeg',['../index.html',1,'']]],
  ['file_1',['file',['../group__lavf__decoding.html#lavf_decoding_open',1,'Opening a media file'],['../group__lavf__decoding.html#lavf_decoding_read',1,'Reading from an opened file']]],
  ['from_20an_20opened_20file_2',['Reading from an opened file',['../group__lavf__decoding.html#lavf_decoding_read',1,'']]],
  ['function_20specific_20information_3',['Function-Specific Information',['../group__lavu__hash__generic.html#Hash',1,'']]]
];
