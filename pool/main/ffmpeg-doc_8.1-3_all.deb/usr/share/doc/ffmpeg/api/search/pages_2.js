var searchData=
[
  ['de_20muxers_0',['Passing options to (de)muxers',['../group__libavf.html#lavf_options',1,'']]],
  ['deprecated_20list_1',['Deprecated List',['../deprecated.html',1,'']]],
  ['directory_2',['Opening a directory',['../group__lavf__io.html#lavf_io_dirlist_open',1,'']]],
  ['directory_20listing_3',['Directory listing',['../group__lavf__io.html#lavf_io_dirlist',1,'']]]
];
