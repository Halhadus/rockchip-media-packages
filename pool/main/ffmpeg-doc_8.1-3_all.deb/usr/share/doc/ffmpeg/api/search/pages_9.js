var searchData=
[
  ['of_20avoptions_0',['Scope of AVOptions',['../group__avoptions.html#avoptions_scope',1,'']]],
  ['opened_20file_1',['Reading from an opened file',['../group__lavf__decoding.html#lavf_decoding_read',1,'']]],
  ['opening_20a_20directory_2',['Opening a directory',['../group__lavf__io.html#lavf_io_dirlist_open',1,'']]],
  ['opening_20a_20media_20file_3',['Opening a media file',['../group__lavf__decoding.html#lavf_decoding_open',1,'']]],
  ['options_20to_20de_20muxers_4',['Passing options to (de)muxers',['../group__libavf.html#lavf_options',1,'']]]
];
