var searchData=
[
  ['rc4_0',['RC4',['../group__lavu__rc4.html',1,'']]],
  ['read_20write_1',['I/O Read/Write',['../group__lavf__io.html',1,'']]],
  ['reading_20option_20values_2',['Reading option values',['../group__opt__read.html',1,'']]],
  ['receive_20encoding_20and_20decoding_20api_20overview_3',['send/receive encoding and decoding API overview',['../group__lavc__encdec.html',1,'']]],
  ['reference_20displays_20information_4',['3D Reference Displays Information',['../group__lavu__video__3d__reference__displays__info.html',1,'']]],
  ['related_5',['related',['../group__lavu__audio.html',1,'Audio related'],['../group__lavu__picture.html',1,'Image related'],['../group__lavu__video.html',1,'Video related']]],
  ['renderer_6',['VDPAU Decoder and Renderer',['../group__lavc__codec__hwaccel__vdpau.html',1,'']]],
  ['riff_20fourccs_7',['RIFF FourCCs',['../group__riff__fourcc.html',1,'']]],
  ['ripemd_8',['RIPEMD',['../group__lavu__ripemd.html',1,'']]]
];
