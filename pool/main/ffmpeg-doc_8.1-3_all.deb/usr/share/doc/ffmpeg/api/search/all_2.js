var searchData=
[
  ['_5fwin32_5fwinnt_0',['_WIN32_WINNT',['../d3d11va_8h.html#ac50762666aa00bd3a4308158510f1748',1,'_WIN32_WINNT:&#160;d3d11va.h'],['../dxva2_8h.html#ac50762666aa00bd3a4308158510f1748',1,'_WIN32_WINNT:&#160;dxva2.h']]]
];
